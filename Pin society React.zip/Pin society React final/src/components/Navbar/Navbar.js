import Logo from "../Assets/Img/Logo sombrero blanco sin fondo.png";
import shop from "../Assets/Img/shopping-cart.png";
import {Link} from "react-router-dom";
import icon from "../Assets/Img/menu_h.png";
import like from "../Assets/Img/heart.png";
import user from "../Assets/Img/user.png";
import lupa from "../Assets/Img/magnifier.png";
import chat from "../Assets/Img/bubble-chat.png";
import categoria from "../Assets/Img/category.png";
import cuidados from "../Assets/Img/sweeping.png";
import nuevos from "../Assets/Img/price-sticker.png";
import personalizar from "../Assets/Img/setting-lines.png";
import React from 'react'
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Offcanvas from 'react-bootstrap/Offcanvas';
import "./Navbar.css";
import Modal from 'react-bootstrap/Modal';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function formenviado() {
  alert("El formulario ha sido enviado");
}

function MyVerticallyCenteredModal(props) {
return (
  <Modal
    {...props}
    size="lg"
    aria-labelledby="contained-modal-title-vcenter"
    centered
    className='modal_añadircat'
  >
    <Modal.Header closeButton>
      <Modal.Title id="contained-modal-title-vcenter">
        Personaliza tu pin
      </Modal.Title>
    </Modal.Header>
    <Modal.Body>
      <form onSubmit={formenviado} className="personalizacion">
        <label>Ingresa una foto de tu diseño:
          <input type="file"></input>
        </label>
        <label>Ingresa el nombre de tu pin:
          <input type="text"></input>
        </label>
        <label>Ingresa la cantidad de pines que deseas:
          <input type="number"></input>
        </label>
        <label>Elige el material que quieres para tu pin:
        <select name="material" id="material">
          <option value="metal">Metal</option>
          <option value="madera">Madera</option>
          <option value="resina">Resina</option>
          <option value="laton">Laton</option>
        </select>
        </label>
        <br></br><br></br>
        <input type="submit" className="botongeneralder"></input>
      </form>
    </Modal.Body>
  </Modal>
);
}

function Navbar(){
  const [modalShow, setModalShow] = React.useState(false);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [openLinks, setOpenLinks] = useState(false);
  const toggleNavbar = () =>{
    setOpenLinks(!openLinks);
};
  return (
  <div>
    <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    <div className="navbar">
      <div className="leftSide" id={openLinks ? "open" : "close"}>
            <img src={Logo} />
            <h1>THE PIN SOCIETY</h1>
        </div>
      <div className="rightSide" >
        <div className="busqueda">
          <input type="text"></input>
          <Link to="/not_found"><img src={lupa}/></Link>
        </div>
        <Link to="/">
        <img src={user}/>
        </Link>
        <Link to="/not_found">
        <img src={like}/>
        </Link>
        <Link to="/not_found">
          <img src={shop}/>
        </Link>
      <div className="menuham">
          <>
      <button onClick={handleShow}>
        <img src={icon}/>
      </button>

      <Offcanvas placement="end" show={show} onHide={handleClose} className="menu_hamburguesa">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title><h1 className="hamtit">The Pin Society</h1></Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
        <h1 className="hamh1"><Link to="/not_found">Cuenta</Link></h1>
        <h1 className="hamh1"><Link to="/not_found">Productos guardados</Link></h1>
        <h1 className="hamh1"><Link to="/not_found">Carrito</Link></h1>
        <h1 className="hamh1"><Link to="/Cuidados">Cuidados y tips</Link></h1>
        <h1 className="hamh1"><Link to="/not_found">Nuevos pines</Link></h1>
        <h1 className="hamh1"><button onClick={() => setModalShow(true)} className="botonham">Personaliza tu pin</button></h1>
        <h1 className="hamh1"><Link to="/Categorias">Categorias</Link></h1>
        <h1 className="hamh1"><Link to="https://wa.link/6ik4z3">Chatea con nosotros</Link></h1>
        </Offcanvas.Body>
      </Offcanvas>
    </>
      </div></div>
    </div>
    <div className='panel'>
      <div className='centrar'>
      <Link to="/Cuidados"><button className='botonespanel'>Cuidados y tips
          <img src={cuidados}/>
      </button></Link>
      <button className='botonespanel'>Nuevos pines
        <img src={nuevos}/>
      </button>
      <button className='botonespanel' onClick={() => setModalShow(true)}>Personalizacion
        <img src={personalizar}/>
      </button>
      <Link to="/Categorias"> <button className='botonespanel'>Categorias
        <img src={categoria}/>
      </button></Link>
      <Link to="https://wa.link/6ik4z3"><button className='botonespanel'>Escribenos
        <img src={chat}/>
      </button></Link>
      </div>
    </div>
  </div>
  );
}

export default Navbar
