import React from 'react'
import '../Ver_categoria.css';
import add from "../components/Assets/Img/add.png";
import abracadabra from "../components/Assets/Img/Abracadabra.jpg";
import fantasma1 from "../components/Assets/Img/Fantasma1.jpeg";
import fantasma2 from "../components/Assets/Img/Fantasma2.jpeg";
import patricio1 from "../components/Assets/Img/Patricio1.jpeg";
import bob_esponja from "../components/Assets/Img/Bob esponja.jpg";
import pez_globo from "../components/Assets/Img/Pez globo.jpg";
import mano from "../components/Assets/Img/Mano.jpg";
import pato from "../components/Assets/Img/Pato.jpg";
import aguacate from "../components/Assets/Img/Aguacate.jpg";
import photo from "../components/Assets/Img/photo.png";
import { useState } from 'react';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import ToggleButton from 'react-bootstrap/ToggleButton';
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import {Link} from "react-router-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"


function ToggleButtonExample() {
    const [checked, setChecked] = useState(false);
    const [radioValue, setRadioValue] = useState('1');
  
    const radios = [
      { name: 'Disponible', value: '1' },
      { name: 'Agotado', value: '2' },
    ];
  
    return (
      <>
        <ButtonGroup>
          {radios.map((radio, idx) => (
            <ToggleButton
              key={idx}
              id={`radio-${idx}`}
              type="radio"
              variant={idx % 2 ? 'outline-danger' : 'outline-success'}
              name="radio"
              value={radio.value}
              checked={radioValue === radio.value}
              onChange={(e) => setRadioValue(e.currentTarget.value)}
            >
              {radio.name}
            </ToggleButton>
          ))}
        </ButtonGroup>
      </>
    );
  }
  

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
        Añadir producto
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="contenidoventanaprod">  
            <div>
                <div className="centrar">
                    <textarea rows="1" cols="10" className="nombreprod">Introduce nombre del producto</textarea>
                </div>
                <div className="centrar">
                    <img src={abracadabra}></img>
                </div>
                <div className="centrar">
                    <input type="file"></input>
                </div>
            </div>
    </div>
      </Modal.Body>
      <Modal.Footer>
        <button class="botongeneral" role="button" onClick={props.onHide}>Añadir</button>
      </Modal.Footer>
    </Modal>
  );
}

function MyVerticallyCenteredModal2(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
          Editar producto
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="contenidoventanaprod">  
              <div>
                  <div className="centrar">
                      <textarea rows="1" cols="10" className="nombreprod">Fantasma 1</textarea>
                  </div>
                  <div className="centrar">
                      <img src={fantasma1}></img>
                  </div>
                  <div className="centrar">
                      <input type="file"></input>
                  </div>
                  <div className="centrar">
                      {ToggleButtonExample()}
                  </div>
              </div>
      </div>
        </Modal.Body>
        <Modal.Footer>
          <button class="botongeneral" role="button" onClick={props.onHide}>Confirmar</button>
        </Modal.Footer>
      </Modal>
    );
  }

function Ver_categorias() {
    const [modalShow, setModalShow] = React.useState(false);
    const [modalShow2, setModalShow2] = React.useState(false);
    return (
        <div>
            <Nav></Nav>
        <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
      <MyVerticallyCenteredModal2
        show={modalShow2}
        onHide={() => setModalShow2(false)}
      />
        <div className="cuerpo">
    <h1 className="titulo">Pines</h1>
        <div className="productoadmin">
            <img src={fantasma1}></img>
            <h1>Fantasma 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={fantasma2}></img>
            <h1>Fantasma 2</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={patricio1}></img>
            <h1>Patricio 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={bob_esponja}></img>
            <h1>Bob Esponja 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={mano}></img>
            <h1>Mano 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={aguacate}></img>
            <h1>Aguacate 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={pez_globo}></img>
            <h1>Pez globo 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={pato}></img>
            <h1>Pato 1</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <div className="productoadmin">
            <img src={photo}></img>
            <h1>Pin 9</h1>
            <a><button className="botonesproductosadmin" role="button" onClick={() => setModalShow2(true)}>Editar producto</button></a>
        </div>
        <a><button onClick={() => setModalShow(true)} className="añadirproducto">
            <img src={add}></img> 
            <h1>Añadir</h1><h1>Producto</h1>
        </button></a>
    </div>
    <Pie></Pie>
    </div>
    )
}
export default Ver_categorias