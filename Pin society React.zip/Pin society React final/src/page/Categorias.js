import React from 'react'
import pines from "../components/Assets/Img/Pines.jpeg";
import anillos from "../components/Assets/Img/Anillos.jpeg";
import stickers from "../components/Assets/Img/Stickers.jpeg";
import add from "../components/Assets/Img/add.png";
import add_img from "../components/Assets/Img/add-image.png";
import x from "../components/Assets/Img/bxs-x-circle.svg";
import '../Categorias.css';
import { useState } from 'react';
import Alert from 'react-bootstrap/Alert';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link} from "react-router-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"



function AlertDismissibleExample() {
    const [show, setShow] = useState(false);
    if (show) {
      return (
        <Alert variant="danger" onClose={() => setShow(false)} dismissible>
          <Alert.Heading>¡Atencion!</Alert.Heading>
          <p>
            Eliminar la categoria es un cambio permanente ¿Desea continuar?
          </p>
          <button onClick={() => setShow(false)} className='botonpromo'>Eliminar Categoria</button>
        </Alert>
      );
    }
    return <button onClick={() => setShow(true)} className='botongeneralder'>Eliminar Cat</button>;
  }

function MyVerticallyCenteredModal(props) {
    const [modalShow2, setModalShow2] = React.useState(false);
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className='modal_añadircat'
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Añadir categoria
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      <MyVerticallyCenteredModal2
            show={modalShow2}
            onHide={() => setModalShow2(false)}
        />
      <div className='contenidoventanacat'><div>
            <div className='centrarcel'><img className='centrarcel' src={add_img}></img></div>
            <div className='centrarcel'><h1 className='centrarcel'>Imagen de la categoria:</h1></div>
            <div className='centrarcel'><input type='file' className='insertarimg'></input></div>
            <div className='centrarcel'><h1 className='centrarcel'>Nombre de la categoria:</h1></div>
            <div className='centrarcel'><textarea rows="1" cols="30" className="nombrecat">Introduce nombre</textarea></div>
            <div className='centrarcel'><h1 className='centrarcel'>Descripcion de la categoria:</h1></div>
            <div className='centrarcel'><textarea rows="6" cols="30" className="descripecat">Introduce descripcion del producto</textarea></div>
        </div>
        <div>
            <div className="espacio"></div>
            <div className="centrar">
                <h2 className="centrar">Precio categoria</h2>
            </div>
        </div>
        <div className="centrar">
            <h3>Inserte el precio para todos los productos de la categoria:</h3>
        </div>
        <div className="centrar">
            <input type="text"></input>
        </div>
        <br></br>
        <div className="centrar">
            <a><button className="botonpromo" role="button" onClick={() => setModalShow2(true)}>Añadir promoción</button></a>
        </div></div>
      </Modal.Body>
      <Modal.Footer>
            <div>
                <button onClick={props.onHide} className="botongeneralder" role="button">Agregar</button>
            </div>  
      </Modal.Footer>
    </Modal>
  );
}

function MyVerticallyCenteredModal2(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        className='modal_añadircat'
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Añadir promocion
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="contenidoventanaprom"> 
        <div><h1>Categoria relacionada:</h1></div>
        <div><div className="centrar">
            <textarea rows="1" cols="20" className="nombreprom">Pines</textarea>
        </div></div>
        <div className='espaciocel'></div>
        <div>
            <h2 className="izquierda">Cantidad:</h2> 
            <h2 className="derecha">Precio por unidad:</h2> 
        </div>
        <div>
            <input type="text" className="izquierda"></input>
            <input type="text" className="derecha"></input>
        </div>
        <div className='espaciocel'></div>
        <h1>Duracion de la promocion (opcional):</h1> 
        <div>
            <h2 className="izquierda">Desde:</h2> 
            <h2 className="derecha">Hasta:</h2> 
        </div>
        <div>
            <input type="text" className="izquierda"></input>
            <input type="text" className="derecha"></input>
        </div>
        <div className='espaciocel'></div>
        <div className="centrar">   
            <a><button className="botonpromo" role="button">Agregar promoción</button></a>
        </div>
        <div className='espaciocel'></div>
        <div className="centrar"><div className="linea"></div></div>
        <div className='espaciocel'></div>
        <div>
            <h3>Promociones existentes:</h3>
            <div className='espaciocel'></div>
            <div className="centrar">
                <div className="promexist">
                    <div>
                        <h4 className="promtype">(3 a 5) x $8.000/und</h4>
                        <h4 className="promduration">Siempre</h4>
                        <a><img src={x}></img></a>
                    </div>
                    <div>
                        <h4 className="promtype">(6 a 9) y (11 o mas) x $7.500/und</h4>
                        <h4 className="promduration">Siempre</h4>
                        <a><img src={x}></img></a>
                    </div>
                    <div>
                        <h4 className="promtype">(10) x $7.000/und</h4>
                        <h4 className="promduration">14/08/23 - 14/11/23</h4>
                        <a><img src={x}></img></a>
                    </div>
                </div>
            </div>
        </div>
        <br></br> 
    </div>
        </Modal.Body>
        <Modal.Footer>
            <div>
                <button onClick={props.onHide} className="botongeneraliz" role="button">Cancelar</button></div><div>
                <button onClick={props.onHide} className="botongeneralder" role="button">Confirmar</button>
            </div>  
        </Modal.Footer>
      </Modal>
    );
  }

function MyVerticallyCenteredModal3(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className='modal_añadircat'
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          {AlertDismissibleExample()}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      <div className='contenidoventanacat'><div>
            <div className='centrarcel'><img className='centrarcel' src={pines}></img></div>
            <div className='centrarcel'><h1 className='centrarcel'>Cambiar img de la categoria:</h1></div>
            <div className='centrarcel'><input type='file' className='insertarimg'></input></div>
            <div className='centrarcel'><h1 className='centrarcel'>Nombre de la categoria:</h1></div>
            <div className='centrarcel'><textarea rows="1" cols="30" className="nombrecat">Pines</textarea></div>
            <div className='centrarcel'><h1 className='centrarcel'>Descripcion de la categoria:</h1></div>
            <div className='centrarcel'><textarea rows="6" cols="30" className="descripecat">Todos los pines son metalicos, con diferentes relieves y tamaños para que encuentres el que mas se ajusta a tu personalidad.</textarea></div>
        </div>
        <div>
            <div className="espacio"></div>
            <div className="centrar">
                <h2 className="centrar">Precio categoria</h2>
            </div>
        </div>
        <div className="centrar">
            <h3>Inserte el precio para todos los productos de la categoria:</h3>
        </div>
        <div className="centrar">
            <textarea rows="1" cols="7" className="nombrecat">$9.000</textarea>
        </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
            <div>
                <button onClick={props.onHide} className="botongeneralder" role="button">Confirmar</button>
            </div>  
      </Modal.Footer>
    </Modal>
  );
}

function Categorias() {
    const [modalShow, setModalShow] = React.useState(false);
    const [modalShow3, setModalShow3] = React.useState(false);
    return (
      <div>
        <Nav></Nav>
        <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
      <MyVerticallyCenteredModal3
        show={modalShow3}
        onHide={() => setModalShow3(false)}
      />
        <div className="cuerpo">
    <h1 className="titulo">Categorias</h1>
        <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={pines}></img>
            <h1>Pines</h1>
            <Link to = "/Ver_categorias"><button className="botonescategoriasadmin" role="button"> Ver Categoria</button></Link> 
            <a><button className="botonescategoriasadmin" role="button" onClick={() => setModalShow3(true)}>Editar Categorias</button></a>
        </div></div></div>
        <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={anillos}></img>
            <h1>Anillos</h1>
            <a><button className="botonescategoriasadmin" role="button">Ver Categoria</button></a>
            <a><button className="botonescategoriasadmin" role="button" onClick={() => setModalShow3(true)}>Editar Categorias</button></a>
        </div></div></div>
        <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={stickers}></img>
            <h1>Stickers</h1>
            <a><button className="botonescategoriasadmin" role="button">Ver Categoria</button></a>
            <a><button className="botonescategoriasadmin" role="button" onClick={() => setModalShow3(true)}>Editar Categorias</button></a>
        </div></div></div>
        <div className='centrarcel'><div><a><button className="añadircategoria" onClick={() => setModalShow(true)}>
            <img src={add}></img>
            <h1>Añadir</h1><h1>Categoria</h1>
        </button></a>
        </div></div></div>
        <Pie></Pie>
      </div>
    );
  }
  
  export default Categorias
  