import React from 'react'
import '../Cuidados.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import pines_ropa from "../components/Assets/Img/Pines_ropa.jpeg";
import pines_ropa2 from "../components/Assets/Img/Pines_ropa2.jpeg";
import {Link} from "react-router-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"



function Cuidados() {
    return (
        <div>
            <Nav></Nav>
            <h1 className='titulo2'>Tips y cuidados para tus pines</h1>
            <div className='contenedortips'>
                <div className='subcontenedortips'>
                <img src={pines_ropa}></img>
                </div>
                <div className='subcontenedortips'>
                    <h2>¿Sabes como cuidar tus pines?</h2>
                    <p>Recuerda que todos los pines que vendemos son metalicos,
                        y el metal no se lleva bien con el agua, aunque unas gotas
                        no le haran daño, recuerda evitar meterlos al agua, no te metas 
                        a bañar, al mar o a la psicina con ellos.
                    </p>
                    <p>Evita colocarlos en prendas muy gruesas, asi la puntilla del pin
                        logre atravesar la tela, puede que la tela sea muy gruesa y eso 
                        haga que el pin quede mal ajustado, asi no se caiga al inicio 
                        se puede caer mas adelante.
                    </p>
                    <p>Tambien evita colocarlos en zonas donde se puedan enrredar facilmente, como 
                        por ejemplo cerca de un bolsillo o cerca de la entrada de una maleta,
                        al salir y entrar objetos constantemente, aumenta la probabilidad de 
                        que alguno se pueda enrredar con el pin y lo pueda arrancar. Mejor 
                        colocalos en zonas donde tengan poco roce con objetos.
                    </p>
                </div>
            </div>
            <div className='contenedortips'>
                <div className='subcontenedortips'>
                    <h2>¿Como combinar tus pins en tus outfits?</h2>
                    <p>Aunque los pines es una accesorio extremadamente versatil, no todos los 
                        pines combinan con absolutamente todo, hay varias cosas que tienes que 
                        preguntarte antes de escoger que pin/s usaras con tu outfit.
                    </p>
                    <p>1. Preguntate que vas a hacer, muchas veces no es cuestion tanto de si 
                        combina o no, si no de lo que vayas a hacer con ese outfit, por ejemplo 
                        si vas a una entrevista de trabajo no vas a usar un pin de hongos, aunque 
                        tambien depende de que impresion quieres dar.
                    </p>
                    <p>2. Piensa en que prenda los vas a usar, ¿La chaqueta? ¿La camiseta? ¿Una maleta?
                        La prenda importa, no solo porque claramente unas prendas son mas visibles que 
                        otras, si no tambien porque no todas las prendas las usas todo el tiempo, en un 
                        dia soleado te puedes quitar la chaqueta y perderas el estilo del pin, mientras 
                        que en la camiseta siempre se vera el pin.
                    </p>
                    <p>3. Es un accesorio mas y como todo accesorio, los colores importan. Aunque sin 
                        duda alguna son mucho mas versatiles y esto te permite usar colores que no combinan 
                        ya que solo sera un puntico de decoracion en tu outfit, igualmente entre mejores colores 
                        escogas, mejor se vera, evita usar pines donde su color dominante sea el mismo de 
                        la prenda, ya que el pin se perdera y no se vera.
                    </p>
                </div>
                <div className='subcontenedortips'>
                <img src={pines_ropa2}></img>
                </div>
            </div>



            <Pie></Pie>
        </div>
    );
}

export default Cuidados