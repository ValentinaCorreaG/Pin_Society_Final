import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import React from 'react';
import Home from "./page/Home";
import Categorias from "./page/Categorias";
import Ver_categorias from "./page/Ver_categoria";
import Cuidados from "./page/Cuidados";
import Not_found from "./page/Not_found";
import {link} from "react-router-dom";

function App() {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path='/Categorias' element = {<Categorias/>}/>
          <Route path='/Ver_categorias' element = {<Ver_categorias/>}/>
          <Route path='/Cuidados' element = {<Cuidados/>}/>
          <Route path='/Not_found' element = {<Not_found/>}/>
        </Routes>
      </BrowserRouter>
    ); 
  }
  export default App;