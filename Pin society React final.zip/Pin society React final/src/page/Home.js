import React from 'react'
import { Outlet, Link } from "react-router-dom";
import adornar from "../components/Assets/Img/Pines.jpeg";
import fantasma1 from "../components/Assets/Img/Fantasma1.jpeg";
import fantasma2 from "../components/Assets/Img/Fantasma2.jpeg";
import patricio1 from "../components/Assets/Img/Patricio1.jpeg";
import pines2 from "../components/Assets/Img/Pines2.jpeg";
import anillos from "../components/Assets/Img/Anillos.jpeg";
import stickers from "../components/Assets/Img/Stickers.jpeg";
import '../Home.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"

function Home() {
  return (
    <div>
        <Nav></Nav>
    <div className="portada">
        <div className='portada2'>
        <img src={adornar}></img>
        <input type='file'></input>
        </div>
        <div className="centrar">
            <div className="txtportada">
                <h1>¿Listo Para <br></br>Adornar tu <br></br> Mundo?</h1>
                <h2>Descubre nuestra coleccion <br></br>unica de accesorios</h2>
            </div>
        </div> 
    </div>
    <div className='espacio'></div>
    <div className='centrar'><div className='linea'></div></div>
    <div className="productosdestacados">
        <h1>Productos Destacados:</h1>
    </div>
    <div className="imgproductosdestacados">
        <div className="centrar">
            <div className='cajaimgcel2'><div className='cajaimgcel'><img src={fantasma1}></img></div><div className='cajaimgcel'><input type='file'></input></div></div>
            <div className='cajaimgcel2'><div className='cajaimgcel'><img src={fantasma2}></img></div><div className='cajaimgcel'><input type='file'></input></div></div>
            <div className='cajaimgcel2'><div className='cajaimgcel'><img src={patricio1}></img></div><div className='cajaimgcel'><input type='file'></input></div></div>
        </div>
    </div>
    <div className='espacio'></div><div className='espacio'></div><div className='espacio'></div>
    <div className='centrar'><div className='linea'></div></div>
    <div className='espacio'></div>
    <div className="imgproductosdestacados">
        <div className="centrar">
            <div className='cajaimgcel2'><div className='cajaimgcel'><Link to="/Categorias"><img src={pines2}></img></Link></div><div className='cajaimgcel'><h2>Pines</h2></div></div>
            <div className='cajaimgcel2'><div className='cajaimgcel'><Link to="/Categorias"><img src={anillos}></img></Link></div><div className='cajaimgcel'><h2>Anillos</h2></div></div>
            <div className='cajaimgcel2'><div className='cajaimgcel'><Link to="/Categorias"><img src={stickers}></img></Link></div><div className='cajaimgcel'><h2>Stickers</h2></div></div>
        </div>
    </div>
    <Pie></Pie>
    </div>
  );
}

export default Home
