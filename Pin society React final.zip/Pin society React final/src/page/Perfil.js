import React from 'react';
import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"
import "./Perfil.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import foto from "../components/Assets/Img/Admin_photo.jpeg";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import modificarDatos from './Modificar_datos';
import {Link} from "react-router-dom";
import x from "../components/Assets/Img/bxs-x-circle.svg";

function MyVerticallyCenteredModal2(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className='modal_añadircat'
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Añadir promocion
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      <div className="contenidoventanaprom"> 
      <div><h1>Categoria relacionada:</h1></div>
      <div><div className="centrar">
          <textarea rows="1" cols="20" className="nombreprom">Pines</textarea>
      </div></div>
      <div className='espaciocel'></div>
      <div>
          <h2 className="izquierda">Cantidad:</h2> 
          <h2 className="derecha">Precio por unidad:</h2> 
      </div>
      <div>
          <input type="text" className="izquierda"></input>
          <input type="text" className="derecha"></input>
      </div>
      <div className='espaciocel'></div>
      <h1>Duracion de la promocion (opcional):</h1> 
      <div>
          <h2 className="izquierda">Desde:</h2> 
          <h2 className="derecha">Hasta:</h2> 
      </div>
      <div>
          <input type="text" className="izquierda"></input>
          <input type="text" className="derecha"></input>
      </div>
      <div className='espaciocel'></div>
      <div className="centrar">   
          <a><button className="botonpromo" role="button">Agregar promoción</button></a>
      </div>
      <div className='espaciocel'></div>
      <div className="centrar"><div className="linea"></div></div>
      <div className='espaciocel'></div>
      <div>
          <h3>Promociones existentes:</h3>
          <div className='espaciocel'></div>
          <div className="centrar">
              <div className="promexist">
                  <div>
                      <h4 className="promtype">(3 a 5) x $8.000/und</h4>
                      <h4 className="promduration">Siempre</h4>
                      <a><img src={x}></img></a>
                  </div>
                  <div>
                      <h4 className="promtype">(6 a 9) y (11 o mas) x $7.500/und</h4>
                      <h4 className="promduration">Siempre</h4>
                      <a><img src={x}></img></a>
                  </div>
                  <div>
                      <h4 className="promtype">(10) x $7.000/und</h4>
                      <h4 className="promduration">14/08/23 - 14/11/23</h4>
                      <a><img src={x}></img></a>
                  </div>
              </div>
          </div>
      </div>
      <br></br> 
  </div>
      </Modal.Body>
      <Modal.Footer>
          <div>
              <button onClick={props.onHide} className="botongeneraliz" role="button">Cancelar</button></div><div>
              <button onClick={props.onHide} className="botongeneralder" role="button">Confirmar</button>
          </div>  
      </Modal.Footer>
    </Modal>
  );
}

function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton className="titulo_modal">
          <Modal.Title id ="contained-modal" >
          Cambiar Contraseña
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className = "contenidoventanapass">
          <div className="contenidoventana">  
            <div>
            <div className = "margin">
            <label htmlFor="user" >Contraseña actual: </label>
            <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
            </div>
            <div className = "margin">
            <label htmlFor="user" >Nueva contraseña: </label>
            <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
            </div>
            <div className = "margin">
            <label htmlFor="user" >Confirmar contraseña: </label>
            <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
            </div>
        </div>
      </div>
        </Modal.Body>
        <Modal.Footer className="titulo_modal">
        <button class="botongeneral" role="button" onClick={(props.onHide)}>Confirmar</button>
        </Modal.Footer>
      </Modal>
    );
  }
function Perfil (){
    const [modalShow, setModalShow] = React.useState(false);
    const [modalShow2, setModalShow2] = React.useState(false);
    return(
    <div>
    <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
      <MyVerticallyCenteredModal2
            show={modalShow2}
            onHide={() => setModalShow2(false)}
        />
    <div>
    <Nav></Nav>
    <div className="centrar">
        <div className = "cuenta_usuario">
            <div className="categoriausuario">
                <img src={foto}></img>
                <h1>Admin Mariana  </h1>
            </div>
            <div className="admin"> 
                <button className= "modificar" variant="primary" onClick={() => setModalShow(true)}>Cambiar contraseña </button>
                <button className= "modificar">
                    <Link to = "/modificarDatos">Modificar Datos </Link></button>
                <MyVerticallyCenteredModal
                show={modalShow}
                onHide={() => setModalShow(false)}
              />
                <button className= "modificar"><Link to = "/Categorias"> Categorias </Link></button>
            </div>      
            <div className ="admin">
                <button className= "modificar"><Link to = "/Ver_categorias"> Productos </Link></button>
                <button className= "modificar" onClick={() => setModalShow2(true)}> Agregar Promoción </button>
                <button className= "modificar"> 
                <Link to = "/usuarios ">Usuarios Registrados </Link></button>
            </div>
        </div>
    </div>
    </div>
</div>
    );
}

export default Perfil;