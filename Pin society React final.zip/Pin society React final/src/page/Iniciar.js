import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"
import "./Iniciar.css";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';


function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
      </Modal.Header>
      <Modal.Body className="custom-modal-text">
        <h4>El correo ha sido envíado exitosamente</h4>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}

function Iniciar(){
  const [modalShow, setModalShow] = React.useState(false);
  const [usuario, setUsuario] = useState('');
  const [clave, setClave] = useState('');
  const [recordar, setRecordar] = useState(false);

  const navigate = useNavigate();

  const handleAccederUsuario = () => {
    if (usuario === 'mariana@admin.com') {
       navigate('/perfil');
    } else {
      alert('Usuario incorrecto. Verifica tus credenciales.');
    }
  };
  
  return (
    <div className='contenedor'>
      <Nav />
      <div className ="titulo_ini">
        <h1> ¡Parece que no has iniciado sesión aún!</h1>
      </div>
      <div className = "centrarchiqui">
      <div className = "centrarchiqui2">
        <div className ="iniciar_sesion">
            <div className ="titulo_iniciar" >
              <h1> Iniciar Sesión </h1>
            </div>
            <div className="usuarios">
      <div id="centrar_usuarios">
        <div>
          <label htmlFor='user'>Nombre de usuario:</label>
        </div>
        <div>
          <input type="text" id="nombre_user" className="nombre" onChange={(e) => setUsuario(e.target.value)} />
        </div>
        <div>
          <label htmlFor="user">Contraseña:</label>
        </div>
        <div>
          <input type="password" id="nombre_user" className="clave" onChange={(e) => setClave(e.target.value)} />
        </div>
        <div>
          <input type="checkbox" id="recordar" className="srecordar" checked={recordar} onChange={() => setRecordar(!recordar)} />
          <label htmlFor="user" id='recordar'> Recordarme </label>
        </div>
        <div>
          <button className="acceder" onClick={handleAccederUsuario}>Acceder</button>
          {usuario === 'mariana@admin.com' && (
            <button className="acceder">
              <Link to="/perfil">Acceder Admin</Link>
            </button>
          )}
        </div>
        <div>
          <h4 className='olvidarcontr'> ¿Haz olvidado tu Contraseña?</h4>
        </div>
      </div>
    </div>
          </div></div>
          <div className = "centrarchiqui2">
          <div className ="iniciar_sesion">
            <div className ="titulo_iniciar" >
              <h1> Registrarse </h1>
            </div>
            <div className = "usuarios">
              <div id="centrar_usuarios">   
              <div>
                  <label htmlFor="user">Correo electronico:</label>
              </div><div>
                  <input type="text" id ="nombre_user" className="nombre"/>
              </div><div>
              <button className="acceder" variant="primary" onClick={() => setModalShow(true)}>
                Enviar Correo
              </button>

              <MyVerticallyCenteredModal
                show={modalShow}
                onHide={() => setModalShow(false)}
              />
           </div><div>
                  <h4 className='enviarcorreo'>Un link sera enviado a su correo electronico para configurar una nueva cuenta</h4>
                </div></div> 
              </div>    
          </div></div>
      </div>
    </div>
  );
};


export default Iniciar;
