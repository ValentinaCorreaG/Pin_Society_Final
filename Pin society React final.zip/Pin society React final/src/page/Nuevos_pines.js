import { useState } from 'react';
import car1 from "../components/Assets/Img/Car1.jpeg"
import car2 from "../components/Assets/Img/Car2.jpeg"
import car3 from "../components/Assets/Img/Car3.jpeg"
import car4 from "../components/Assets/Img/car4.jpeg"
import car5 from "../components/Assets/Img/car5.jpeg"
import car6 from "../components/Assets/Img/car6.jpeg"
import React from 'react';
import "./Perfil.css"

import Carousel from 'react-bootstrap/Carousel';
import Nav from "../components/Navbar/Navbar"
function ControlledCarousel() {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  return (
    <div className='car_cen'>
        <Nav/>
   
    <Carousel activeIndex={index} onSelect={handleSelect}>
      <Carousel.Item >
        <img
          style={{ height: '450px', width: 'auto', margin: '0 auto', display: 'block' }}
          src={car1}
          alt= "100px"
        />
        <Carousel.Caption>
          <h3 style={{ fontFamily: 'Passion One', fontSize: "20pt", color: '#3A3758' }}>Colección de personajes</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          style={{ height: '450px', width: 'auto', margin: '0 auto', display: 'block' }}
          src={car2}
          alt="Second slide"
        />
        <Carousel.Caption>
          <h3 style={{ fontFamily: 'Passion One', fontSize: "20pt", color: '#3A3758' }}>Un poco más animado </h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className="carrusel">
        <img
          style={{ height: '450px', width: 'auto', margin: '0 auto', display: 'block' }}
          src={car3}
          alt="Third slide"
        />
        <Carousel.Caption>
          <h3 style={{ fontFamily: 'Passion One', fontSize: "20pt", color: '#3A3758' }}>Para los amantes de los animales </h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          style={{ height: '450px', width: 'auto', margin: '0 auto', display: 'block' }}
          src={car4}
          alt="First slide"
        />
        <Carousel.Caption>
          <h3 style={{ fontFamily: 'Passion One', fontSize: "20pt", color: '#3A3758' }}> Un poco más aesthetic </h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          style={{ height: '450px', width: 'auto', margin: '0 auto', display: 'block' }}
          src={car5}
          alt="First slide"
        />
        <Carousel.Caption>
          <h3 style={{ fontFamily: 'Passion One', fontSize: "20pt", color: '#3A3758' }}> El amarillo te luce </h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          style={{ height: '450px', width: 'auto', margin: '0 auto', display: 'block' }}
          src={car6}
          alt="First slide"
        />
        <Carousel.Caption>
          <h3 style={{ fontFamily: 'Passion One', fontSize: "20pt", color: '#3A3758' }}> y los gatitos que no pueden faltar</h3>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    </div>
  );
}

export default ControlledCarousel;
