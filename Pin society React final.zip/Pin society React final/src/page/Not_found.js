import React from 'react'
import '../404.css';
import {Link} from "react-router-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function not_found() {
    return (
        <div>
        <div className="cuerpo">
        <div className='notfound'>
            <div className="noise"></div>
            <div className="overlay"></div>
            <div className="terminal">
                <h1>Error <span class="errorcode">404</span></h1>
                <p className="output">La pagina que estas buscando no se encuentra disponible, seguimos trabajando en esto.</p>
                <p className="output">Por favor <Link to = "/">regresa a la pagina de inicio</Link>.</p>
                <p className="output">Buena suerte.</p>
            </div>
        </div>
        </div></div>
    );
}

export default not_found