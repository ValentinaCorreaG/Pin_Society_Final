import React from 'react';
import Nav from "../components/Navbar/Navbar"
import Pie from "../components/Pie/Pie"
import "./Perfil.css"
import { useState } from 'react';
import Alert from 'react-bootstrap/Alert';
import Button from 'react-bootstrap/Button';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import foto from "../components/Assets/Img/Admin_photo.jpeg"
import Modal from 'react-bootstrap/Modal';
import modificarDatos from './Modificar_datos';
import {Link} from "react-router-dom";

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton className="titulo_modal">
        <Modal.Title id ="contained-modal" >
        Cambiar Contraseña
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className = "contenidoventanapass">
        <div className="contenidoventana">  
          <div>
          <div className = "margin">
          <label htmlFor="user" >Contraseña actual: </label>
          <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
          </div>
          <div className = "margin">
          <label htmlFor="user" >Nueva contraseña: </label>
          <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
          </div>
          <div className = "margin">
          <label htmlFor="user" >Confirmar contraseña: </label>
          <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
          </div>
      </div>
    </div>
      </Modal.Body>
      <Modal.Footer className="titulo_modal">
      <button class="botongeneral" role="button" onClick={(props.onHide)}>Confirmar</button>
      </Modal.Footer>
    </Modal>
  );
}

function ModificarDatos(){
    const [show, setShow] = useState(true);
    const [modalShow, setModalShow] = React.useState(false);
    const handleGuardar = () => {
      alert('Datos modificados correctamente');
    };
      
    // Estados para los datos modificables
    const [nombreEmpresa, setNombreEmpresa] = useState('The Pin Society');
    const [redesSociales, setRedesSociales] = useState('@ThepinSociety');
    const [ubicacion, setUbicacion] = useState('Casur Claustro');
    const [detalles, setDetalles] = useState('Universidad del Rosario');
    const [correo, setCorreo] = useState('thepinsociety@gmail.com');
    const [nombreCompleto, setNombreCompleto] = useState('Pepito Perez Gonzalez');
    const [telefono, setTelefono] = useState('310 234567');
    const [direccion, setDireccion] = useState('Carrera 1 # 23-45');
    const [torreAptoCasa, setTorreAptoCasa] = useState('Torre 21 Apto 901');
    const [correoUsuario, setCorreoUsuario] = useState('pepitoperez@gmail.com');
    
    const handleGuardarCambios = () => {
        // Aquí puedes agregar lógica para guardar los datos (por ejemplo, llamadas a una API)
        // En este ejemplo, solo mostramos la alerta de que los datos se han modificado
        setShow(false);
    };
    return(
    <div>
    <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    <div>
    <Nav></Nav>
    <div>
    <button className= "modificar" id="centro" variant="primary" onClick={() => setModalShow(true)}>Cambiar contraseña </button>     
        </div>

        <div className="centrar">
            <div className="modi_datadmin">
            <div className = "cuenta_usuario">
                <div className="categoriausuario">
                    <img src={foto}></img>
                    <h1>Admin Mariana Urrego </h1>
                </div>
            <div className="data_admin">
            <div className="formula_admin"> 
            <div>
                <label htmlFor="user" >Nombre Empresa:</label>
                <input type="text" id="nombre_user" value={nombreEmpresa} style={{ color: 'white' }} onChange={(e) => setNombreEmpresa(e.target.value)} />
          </div>
            <div >
                <label htmlFor="user">Redes sociales: </label>
                <input type="text" id="nombre_user" value={redesSociales} style={{ color: 'white' }} onChange={(e) => setRedesSociales(e.target.value)} />
          </div>
            <div>
                <label htmlFor="user">Ubicación: </label>
                <input type="text" id="nombre_user" value={ubicacion} style={{ color: 'white' }} onChange={(e) => setUbicacion(e.target.value)} />
          </div>
            <div >
                <label htmlFor="user"> Detalles: </label>
                <input type="text" id="nombre_user" value={detalles} style={{ color: 'white' }} onChange={(e) => setDetalles(e.target.value)} />
          </div>
            <div >
                <label htmlFor="user"> Correo: </label>
                <input type="text" id="nombre_user" value={correo} style={{ color: 'white' }} onChange={(e) => setCorreo(e.target.value)} />
          </div>
            </div> 
            <div id="formula">   
            <div>
                <label htmlFor="user">Nombre Completo:</label>
                <input type="text" id="nombre_user" value={nombreCompleto} style={{ color: 'white' }} onChange={(e) => setNombreCompleto(e.target.value)} />
          </div>
            <div>
                <label htmlFor="user"> Número de Telefono : </label>
                <input type="text" id="nombre_user" value={telefono} style={{ color: 'white' }} onChange={(e) => setTelefono(e.target.value)} />
          </div>
            <div>
                <label htmlFor="user"> Dirección: </label>
                <input type="text" id="nombre_user" value={direccion} style={{ color: 'white' }} onChange={(e) => setDireccion(e.target.value)} />
          </div>
            <div>
                <label htmlFor="user"> Torre/Apto/Casa: </label>
                <input type="text" id="nombre_user" value={torreAptoCasa} style={{ color: 'white' }} onChange={(e) => setTorreAptoCasa(e.target.value)} />
          </div>
            </div> 
           <div>
            </div>
            </div>
            </div>
            </div>
            </div>
        <div>
        <button className="modificar" variant="primary" id = "centro" onClick={handleGuardar}>
                Guardar Cambios 
              </button>
           </div><div>
          </div></div> 

      </div>
    );
}

export default ModificarDatos;