import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Redirect,  Navigate } from "react-router-dom";
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from "./page/Home";
import Categorias from "./page/Categorias";
import Ver_categorias from "./page/Ver_categoria";
import Cuidados from "./page/Cuidados";
import Not_found from "./page/Not_found";
import {link} from "react-router-dom";
import Iniciar from "./page/Iniciar"
import Perfil from "./page/Perfil";
import Usuarios_registrados from "./page/Usuarios_registrados";
import ModificarDatos from "./page/Modificar_datos";
import Edit_user from "./page/Edit_user";
import Registro from "./page/registrar";
import New from "./page/Nuevos_pines";


  function App() {
    const usuarioActual = "mariana@admin.com"; 
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/inicio" element={<Iniciar/>}/>
          {usuarioActual === "mariana@admin.com" ? (
           <Route path='/perfil' element ={<Perfil/>}/>
        ) : (
          <Navigate to="/" />
        )}
          <Route path='/modificarDatos' element = {<ModificarDatos/>}/>
          <Route path = '/usuarios' element = {<Usuarios_registrados></Usuarios_registrados>}></Route>
          <Route path = "/Edit_user" element ={<Edit_user/>}/>
          <Route path = "/registro" element = {<Registro/>}/>
          <Route path = "/new" element = {<New/>}/>
          <Route path='/Categorias' element = {<Categorias/>}/>
          <Route path='/Ver_categorias' element = {<Ver_categorias/>}/>
          <Route path='/Cuidados' element = {<Cuidados/>}/>
          <Route path='/Not_found' element = {<Not_found/>}/>
        </Routes>
      </BrowserRouter>
    ); 
  }
  export default App;