import React from 'react'
import "./Perfil.css"
import { useState } from 'react';
import Alert from 'react-bootstrap/Alert';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Nav from "../components/Navbar/Navbar"
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link} from "react-router-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import p1 from "../components/Assets/Img/avatar_.jpeg"

function Edit_user (){
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [nombreCompleto, setNombreCompleto] = useState('Pepito Perez Gonzalez');
    const [telefono, setTelefono] = useState('310 234567');
    const [direccion, setDireccion] = useState('Carrera 1 # 23-45');
    const [torreAptoCasa, setTorreAptoCasa] = useState('Torre 21 Apto 901');
    const [correoUsuario, setCorreoUsuario] = useState('pepitoperez@gmail.com');
    
    const handleGuardarCambios = () => {
        setShow(false);
    };
    return(
   
    <div>
    <Nav></Nav>
    <div>
    <button className="modificar" id="centro" role="button" variant="primary" onClick={handleShow}> Eliminar usuario </button>
        <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton className = "alerta">
          <Modal.Title >¡Atencion!</Modal.Title>
        </Modal.Header >
        <Modal.Body className = "alerta">Eliminar el usuario es un cambio permanente ¿Desea continuar?
        </Modal.Body>
        <Modal.Footer className = "alerta">
          <Button className= "botonescategorias" variant="secondary" onClick={handleClose}>
            Cerrar
          </Button>
          <Button className="botonescategorias" variant="primary" onClick={handleClose}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
    <div className="centrar">
        <div className="modi_datadmin">
            <div className="categoriausuario">
                    <img src={p1}></img>
                    <h1>Usuario_123 </h1>
                    <h5>pepitoperez@gmail.com</h5>
                </div>
            <div id="formula_user">   
            <div className = "label-input-container">
                <label htmlFor="user">Nombre Completo:</label>
                <input type="text" id="nombre_user" value={nombreCompleto} style={{ color: 'white' }} onChange={(e) => setNombreCompleto(e.target.value)} />
            </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Número de Telefono : </label>
                <input type="text" id="nombre_user" value={telefono} style={{ color: 'white' }} onChange={(e) => setTelefono(e.target.value)} />
            </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Dirección: </label>
                <input type="text" id="nombre_user" value={direccion} style={{ color: 'white' }} onChange={(e) => setDireccion(e.target.value)} />
            </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Torre/Apto/Casa: </label>
                <input type="text" id="nombre_user" value={torreAptoCasa} style={{ color: 'white' }} onChange={(e) => setTorreAptoCasa(e.target.value)} />
          </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Correo: </label>
                <input type="text" id="nombre_user" value={correoUsuario} style={{ color: 'white' }} onChange={(e) => setCorreoUsuario(e.target.value)} />
          </div>
            </div> 
        </div>
    </div>
        <div>
        <Link to = "/usuarios"><button className="modificar" id="centro" role="button"> Guardar Cambios </button></Link> 
    </div>
</div>
);
}

export default Edit_user;
