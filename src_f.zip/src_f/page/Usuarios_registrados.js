import React from 'react'
import pines from "../components/Assets/Img/Pines.jpeg";
import anillos from "../components/Assets/Img/Anillos.jpeg";
import stickers from "../components/Assets/Img/Stickers.jpeg";
import "./Usuarios_registrados.css"
import { useState } from 'react';
import Alert from 'react-bootstrap/Alert';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link} from "react-router-dom";
import Edit_user from "./Edit_user.js";
import Nav from "../components/Navbar/Navbar"
import p1 from "../components/Assets/Img/avatar_.jpeg"
import p2 from "../components/Assets/Img/avatar_1.jpg"
import p3 from "../components/Assets/Img/avatar_3.jpeg"
import p4 from "../components/Assets/Img/avatar_4.jpg"
import add from "../components/Assets/Img/add.png"
import registro from "./registrar.js"
import { BrowserRouter, Routes, Route } from "react-router-dom";

function Usuarios_registrados() {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
      <div>
        <Nav></Nav>
        <div className="cuerpo">
    <h1 className="titulo">Usuarios Registrados </h1>
        <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={p1}></img>
            <h1>Usuario_123</h1>
            <Link to = "/Edit_user"><button className="botonescategoriasadmin" role="button"> Editar Información</button></Link> 
            <button className="botonescategoriasadmin" role="button" variant="primary" onClick={handleShow}> Eliminar usuario </button>
            <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton className = "alerta">
          <Modal.Title >¡Atencion!</Modal.Title>
        </Modal.Header >
        <Modal.Body className = "alerta">Eliminar el usuario es un cambio permanente ¿Desea continuar?
        </Modal.Body>
        <Modal.Footer className = "alerta">
          <Button className= "botonescategorias" variant="secondary" onClick={handleClose}>
            Cerrar
          </Button>
          <Button className="botonescategorias" variant="primary" onClick={handleClose}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>
       </div></div></div>
       <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={p2}></img>
            <h1>Usuario_998</h1>
            <Link to = "/Edit_user"><button className="botonescategoriasadmin" role="button"> Editar Información</button></Link> 
            <button className="botonescategoriasadmin" role="button" variant="primary" onClick={handleShow}> Eliminar usuario </button>
            <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton className = "alerta">
          <Modal.Title >¡Atencion!</Modal.Title>
        </Modal.Header >
        <Modal.Body className = "alerta">Eliminar el usuario es un cambio permanente ¿Desea continuar?
        </Modal.Body>
        <Modal.Footer className = "alerta">
          <Button className= "botonescategorias" variant="secondary" onClick={handleClose}>
            Cerrar
          </Button>
          <Button className="botonescategorias" variant="primary" onClick={handleClose}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>
      </div></div></div>
      <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={p3}></img>
            <h1>Usuario_776</h1>
            <Link to = "/Edit_user"><button className="botonescategoriasadmin" role="button"> Editar Información</button></Link> 
            <button className="botonescategoriasadmin" role="button" variant="primary" onClick={handleShow}> Eliminar usuario </button>
            <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton className = "alerta">
          <Modal.Title >¡Atencion!</Modal.Title>
        </Modal.Header >
        <Modal.Body className = "alerta">Eliminar el usuario es un cambio permanente ¿Desea continuar?
        </Modal.Body>
        <Modal.Footer className = "alerta">
          <Button className= "botonescategorias" variant="secondary" onClick={handleClose}>
            Cerrar
          </Button>
          <Button className="botonescategorias" variant="primary" onClick={handleClose}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>
      </div></div></div>
      <div className='centrarcel'><div><div className="categoriaadmin">
            <img src={p4}></img>
            <h1>Usuario_334</h1>
            <Link to = "/Edit_user"><button className="botonescategoriasadmin" role="button"> Editar Información</button></Link> 
            <button className="botonescategoriasadmin" role="button" variant="primary" onClick={handleShow}> Eliminar usuario </button>
            <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton className = "alerta">
          <Modal.Title >¡Atencion!</Modal.Title>
        </Modal.Header >
        <Modal.Body className = "alerta">Eliminar el usuario es un cambio permanente ¿Desea continuar?
        </Modal.Body>
        <Modal.Footer className = "alerta">
          <Button className= "botonescategorias" variant="secondary" onClick={handleClose}>
            Cerrar
          </Button>
          <Button className="botonescategorias" variant="primary" onClick={handleClose}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>
        </div></div></div>

        <div className='centrarcel'><div><a><button className="añadircategoria" >
            
        <Link to = "/registro">
            <img src={add}>
            </img></Link> 
            <h1>Añadir</h1><h1>Usuario</h1>
            
        </button></a>
        </div></div></div>
      </div>
    );
  }
  
  export default Usuarios_registrados