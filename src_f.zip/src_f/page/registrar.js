import React from 'react'
import "./Perfil.css"
import { useState } from 'react';
import Alert from 'react-bootstrap/Alert';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Nav from "../components/Navbar/Navbar"
import 'bootstrap/dist/css/bootstrap.min.css';
import {Link} from "react-router-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import p1 from "../components/Assets/Img/avatar_.jpeg"
import add from "../components/Assets/Img/add.png"
function Registro (){
    return(
    <div>
    <Nav></Nav>
    <div className="centrar">
        <div className="modi_datadmin">
            <div className="categoriausuario">
                    <img src={add}></img>
                    <h1>Usuario_9990 </h1>
                    <h5>pepitoperez@gmail.com</h5>
                </div>
            <div id="formula_user">   
            <div className = "label-input-container">
                <label htmlFor="user">Nombre Completo:</label>
                <input type="text" id="nombre_user"  />
            </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Número de Telefono : </label>
                <input type="text" id="nombre_user" />
            </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Dirección: </label>
                <input type="text" id="nombre_user"  />
            </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Torre/Apto/Casa: </label>
                <input type="text" id="nombre_user" />
          </div>
            <div className = "label-input-container">
                <label htmlFor="user"> Correo: </label>
                <input type="text" id="nombre_user"  />
          </div>
            </div> 
        </div>
    </div>
        <div>
        <Link to = "/usuarios"><button className="modificar" id="centro" role="button"> Guardar Usuario </button></Link> 
    </div>
</div>
);
}

export default Registro;