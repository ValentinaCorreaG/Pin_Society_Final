import React from 'react';
import ig from "../Assets/Img/instagram.png";
import nequi from "../Assets/Img/nequi.png";
import bancolombia from "../Assets/Img/bancolombia.png";
import daviplata from "../Assets/Img/daviplata.png";
import "./pie.css";
function pie() {
  return (
    <div >
    <div className="piedepagina">
      <div className="metodosdepago">
        <div className='left'>
        <img src={ig} id="ing" />
        <a className="titulo">@thepinsociety_</a>
        </div>
        <div className='right'>
            <img src={nequi} id="pago" />
            <img src={daviplata} id="pago" />
            <img src={bancolombia} id="pago" />
        </div>
      </div>
    </div>
    </div>
  );
}

export default pie;
