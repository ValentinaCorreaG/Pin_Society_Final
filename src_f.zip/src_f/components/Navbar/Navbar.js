import Logo from "../Assets/Img/Logo sombrero blanco sin fondo.png";
import shop from "../Assets/Img/shopping-cart.png";
import {Link} from "react-router-dom";
import icon from "../Assets/Img/menu_h.png";
import like from "../Assets/Img/heart.png";
import user from "../Assets/Img/user.png";
import lupa from "../Assets/Img/magnifier.png";
import chat from "../Assets/Img/bubble-chat.png";
import categoria from "../Assets/Img/category.png";
import cuidados from "../Assets/Img/sweeping.png";
import nuevos from "../Assets/Img/price-sticker.png";
import personalizar from "../Assets/Img/setting-lines.png";
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Offcanvas from 'react-bootstrap/Offcanvas';
import "./Navbar.css";
function Navbar(){
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [openLinks, setOpenLinks] = useState(false);
  const toggleNavbar = () =>{
    setOpenLinks(!openLinks);
};
  return (
  <div>
    <div className="navbar">
      <div className="leftSide" id={openLinks ? "open" : "close"}>
            <img src={Logo} />
            <h1>THE PIN SOCIETY</h1>
        </div>
      <div className="rightSide" >
        <div className="busqueda">
          <input type="text"></input>
          <img src={lupa}/>
        </div>
        <Link to="/perfil">
        <img src={user}/>
        </Link>
        <Link to="/">
        <img src={like}/>
        </Link>
        <Link to="/">
          <img src={shop}/>
        </Link>
      <div className="menuham">
        <Link to="/">
          <>
      <button onClick={handleShow}>
        <img src={icon}/>
      </button>

      <Offcanvas placement="end" show={show} onHide={handleClose} className="menu_hamburguesa">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title><h1 className="hamtit">The Pin Society</h1></Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
        <h1 className="hamh1">Cuenta</h1>
        <h1 className="hamh1">Productos guardados</h1>
        <h1 className="hamh1">Carrito</h1>
        <h1 className="hamh1">Cuidados especiales</h1>
        <Link to = "/new">
        <h1 className="hamh1">Nuevos pines</h1>
        </Link>
        <h1 className="hamh1">Personaliza tu pin</h1>
        <h1 className="hamh1">Categorias</h1>
        <h1 className="hamh1">Chatea con nosotros</h1>
        </Offcanvas.Body>
      </Offcanvas>
    </>
        </Link>
      </div></div>
    </div>
    <div className='panel'>
      <div className='centrar'>
      <button className='botonespanel'>Cuidados
          <img src={cuidados}/>
      </button>
      <Link to = "/new">
      <button className='botonespanel'>Nuevos pines
        <img src={nuevos}></img>
        </button>
        </Link>
          
     
      <button className='botonespanel'>Personalizacion
        <img src={personalizar}/>
      </button>
      <button className='botonespanel'>Categorias
        <img src={categoria}/>
      </button>
      <button className='botonespanel'>Escribenos
        <img src={chat}/>
      </button>
      </div>
    </div>
  </div>
  );
}

export default Navbar
