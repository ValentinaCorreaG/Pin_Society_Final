import React from 'react';
import './App.css';
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Redirect,  Navigate } from "react-router-dom";
import Iniciar from "./page/Iniciar"
import 'bootstrap/dist/css/bootstrap.min.css';
import Perfil from "./page/Perfil";
import Usuarios_registrados from "./page/Usuarios_registrados";
import ModificarDatos from "./page/Modificar_datos";
import Edit_user from "./page/Edit_user"
import Registro from "./page/registrar"
import New from "./page/Nuevos_pines"
function App() {
  const usuarioActual = "mariana@admin.com"; 
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/inicio" element={<Iniciar/>}/>
        {usuarioActual === "mariana@admin.com" ? (
         <Route path='/perfil' element ={<Perfil/>}/>
      ) : (
        <Navigate to="/" />
      )}
        <Route path='/modificarDatos' element = {<ModificarDatos/>}/>
        <Route path = '/usuarios' element = {<Usuarios_registrados></Usuarios_registrados>}></Route>
        <Route path = "/Edit_user" element ={<Edit_user/>}/>
        <Route path = "/registro" element = {<Registro/>}/>
        <Route path = "/new" element = {<New/>}/>
      </Routes>
    </BrowserRouter>
  ); 
}
export default App;
