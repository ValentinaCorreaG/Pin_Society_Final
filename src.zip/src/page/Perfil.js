import React from 'react';
import Nav from '../components/Navbar/Navbar';
import Pie from '../components/Pie/pie';
import "./Perfil.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import foto from "../components/Assets/Img/Admin_photo.jpeg";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import modificarDatos from './Modificar_datos';
import {Link} from "react-router-dom";

function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton className="titulo_modal">
          <Modal.Title id ="contained-modal" >
          Cambiar Contraseña
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className = "contenidoventanapass">
          <div className="contenidoventana">  
            <div>
            <div className = "margin">
            <label htmlFor="user" >Contraseña actual: </label>
            <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
            </div>
            <div className = "margin">
            <label htmlFor="user" >Nueva contraseña: </label>
            <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
            </div>
            <div className = "margin">
            <label htmlFor="user" >Confirmar contraseña: </label>
            <input type="password" id ="register_user" style={{ color: 'white' }}></input>  
            </div>
        </div>
      </div>
        </Modal.Body>
        <Modal.Footer>
        <button class="botongeneral" role="button" onClick={(props.onHide)}>Confirmar</button>
        </Modal.Footer>
      </Modal>
    );
  }
function Perfil (){
    const [modalShow, setModalShow] = React.useState(false);
    return(
    <div>
    <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    <div>
    <Nav></Nav>
    <div className="centrar">
        <div className = "cuenta_usuario">
            <div className="categoriausuario">
                <img src={foto}></img>
                <h1>Admin Mariana  </h1>
            </div>
            <div className="admin"> 
                <button className= "modificar" variant="primary" onClick={() => setModalShow(true)}>Cambiar contraseña </button>
                <button className= "modificar">
                    <Link to = "/modificarDatos">Modificar Datos </Link></button>
                <MyVerticallyCenteredModal
                show={modalShow}
                onHide={() => setModalShow(false)}
              />
                <button className= "modificar"> Categorias </button>
            </div>      
            <div className ="admin">
                <button className= "modificar"> Productos </button>
                <button className= "modificar"> Agregar Promoción </button>
                <button className= "modificar"> Usuarios Registrados</button>
            </div>
        </div>
    </div>
    </div>
</div>
    );
}

export default Perfil;