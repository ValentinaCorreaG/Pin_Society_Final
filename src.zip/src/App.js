import React from 'react';
import './App.css';
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Redirect,  Navigate } from "react-router-dom";
import Home from "./page/Home"
import 'bootstrap/dist/css/bootstrap.min.css';
import Perfil from "./page/Perfil";
import ModificarDatos from "./page/Modificar_datos";
function App() {
  const usuarioActual = "mariana@admin.com"; 
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>}/>
        {usuarioActual === "mariana@admin.com" ? (
         <Route path='/perfil' element ={<Perfil/>}/>
      ) : (
        <Navigate to="/" />
      )}
        <Route path='/modificarDatos' element = {<ModificarDatos/>}/>
      </Routes>
    </BrowserRouter>
  ); 
}
export default App;
